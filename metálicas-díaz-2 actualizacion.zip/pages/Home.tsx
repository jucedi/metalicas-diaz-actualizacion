import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, ShieldCheck, Clock, Award } from 'lucide-react';
import { Link } from 'react-router-dom';
import Button from '../components/Button';

const Home: React.FC = () => {
  return (
    <div className="w-full">
      {/* Hero Section */}
      <section 
        className="relative h-screen min-h-[600px] flex items-center justify-center bg-fixed bg-cover bg-center"
        style={{ backgroundImage: 'url("https://picsum.photos/1920/1080?grayscale")' }}
      >
        {/* Overlay */}
        <div className="absolute inset-0 bg-brand-navy/60 z-10"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-brand-navy via-transparent to-transparent z-10"></div>

        <div className="relative z-20 text-center px-4 max-w-4xl mx-auto">
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight"
          >
            Construimos Tu <br/>
            <span className="text-brand-gold">Futuro en Metal</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-lg md:text-xl text-brand-softSteel mb-8 max-w-2xl mx-auto"
          >
            Ingeniería de precisión y diseño industrial para proyectos que desafían el tiempo. Expertos en metalistería, aluminio y soluciones modulares.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Link to="/proyectos">
              <Button>Ver Proyectos <ArrowRight size={18} /></Button>
            </Link>
            <Link to="/contacto">
              <Button variant="outline" className="text-white border-white hover:bg-white hover:text-brand-navy">
                Solicitar Presupuesto
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Pillars Section */}
      <section className="py-20 bg-brand-ice px-4 md:px-8">
        <div className="container mx-auto max-w-7xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-brand-navy mb-4">Nuestros Pilares</h2>
            <div className="w-24 h-1 bg-brand-gold mx-auto rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { title: "Innovación Técnica", desc: "Utilizamos maquinaria CNC de última generación para cortes y dobleces de precisión milimétrica.", img: "https://picsum.photos/600/400?random=1" },
              { title: "Diseño Moderno", desc: "Fusionamos funcionalidad industrial con estética contemporánea para espacios únicos.", img: "https://picsum.photos/600/400?random=2" },
              { title: "Sostenibilidad", desc: "Procesos optimizados para reducir residuos y materiales 100% reciclables.", img: "https://picsum.photos/600/400?random=3" }
            ].map((item, idx) => (
              <motion.div 
                key={idx}
                whileHover={{ y: -10 }}
                className="bg-white rounded-2xl shadow-lg overflow-hidden group"
              >
                <div className="overflow-hidden h-56">
                  <img 
                    src={item.img} 
                    alt={item.title} 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
                  />
                </div>
                <div className="p-8">
                  <h3 className="text-xl font-bold text-brand-navy mb-3">{item.title}</h3>
                  <p className="text-brand-steel leading-relaxed">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust Indicators */}
      <section className="py-16 bg-brand-navy text-white px-4 md:px-8">
        <div className="container mx-auto max-w-7xl">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center divide-y md:divide-y-0 md:divide-x divide-white/10">
            <div className="p-4 flex flex-col items-center">
              <div className="w-16 h-16 bg-brand-gold/10 rounded-full flex items-center justify-center mb-4 text-brand-gold">
                <ShieldCheck size={32} />
              </div>
              <h3 className="text-xl font-bold mb-2">Garantía Certificada</h3>
              <p className="text-brand-softSteel text-sm">Todos nuestros materiales cuentan con certificación ISO de calidad.</p>
            </div>
            <div className="p-4 flex flex-col items-center">
              <div className="w-16 h-16 bg-brand-gold/10 rounded-full flex items-center justify-center mb-4 text-brand-gold">
                <Clock size={32} />
              </div>
              <h3 className="text-xl font-bold mb-2">Entrega Puntual</h3>
              <p className="text-brand-softSteel text-sm">Respetamos rigurosamente los cronogramas de obra pactados.</p>
            </div>
            <div className="p-4 flex flex-col items-center">
              <div className="w-16 h-16 bg-brand-gold/10 rounded-full flex items-center justify-center mb-4 text-brand-gold">
                <Award size={32} />
              </div>
              <h3 className="text-xl font-bold mb-2">+20 Años de Experiencia</h3>
              <p className="text-brand-softSteel text-sm">Dos décadas liderando el sector metalúrgico en la región.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;