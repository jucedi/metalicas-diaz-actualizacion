import React from 'react';
import { MessageCircle } from 'lucide-react';
import { motion } from 'framer-motion';

const WhatsAppBtn: React.FC = () => {
  return (
    <motion.a
      href="https://wa.me/1234567890" // Replace with real number
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 bg-brand-navy text-white p-4 rounded-full shadow-lg border-2 border-brand-gold/20 hover:bg-brand-gold hover:text-brand-navy transition-colors duration-300 flex items-center justify-center"
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      whileHover={{ scale: 1.1 }}
    >
      <MessageCircle size={32} />
    </motion.a>
  );
};

export default WhatsAppBtn;